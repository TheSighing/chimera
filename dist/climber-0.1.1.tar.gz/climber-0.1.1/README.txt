=============================
climber
=============================

Crawls wiki pages and creates summaries.

Documentation
-------------

The full documentation is at https://climber.readthedocs.org.

Quickstart
----------

Install climber::

    pip install climber

Then use it in a project::

    import climber

Features
--------

* TODO

Running Tests
--------------

Does the code actually work?

::

    source <YOURVIRTUALENV>/bin/activate
    (myenv) $ pip install -r requirements_test.txt
    (myenv) $ python runtests.py

Credits
---------

Tools used in rendering this package:

*  Cookiecutter_
*  `cookiecutter-djangopackage`_

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`cookiecutter-djangopackage`: https://github.com/pydanny/cookiecutter-djangopackage
